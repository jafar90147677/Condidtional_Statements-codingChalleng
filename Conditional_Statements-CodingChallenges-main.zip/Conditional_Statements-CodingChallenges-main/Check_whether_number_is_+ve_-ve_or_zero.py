# Write a program to check whether the given number is positive, zero or negative.

number = float(input("Enter the number:"))
if number > 0:
    print("Positive Number")

elif number < 0:
    print("Negative Number")

else:
    print("Zero Number")