# Write a program to check whether a person is eligible for voting or not.(voting age >=18)
# Enter your age : 19
# You are allowed to vote

age = int(input("Enter the age:"))

if age >= 18:
    print("You are allowed to vote")
else:
    print("You are not allowed to vote")