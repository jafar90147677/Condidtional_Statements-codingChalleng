number = int(input("Enter the number:"))
if (number % 2) == 0:
    print("Even number")
else:
    print("Odd number")